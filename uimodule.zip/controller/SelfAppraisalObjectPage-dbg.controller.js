sap.ui.define([
    "com/infocus/GraphitePms/controller/BaseController",
    'sap/ui/model/json/JSONModel',
    "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
], 

function (Controller,JSONModel,Filter,FilterOperator){
    "use strict";

    return Controller.extend("com.infocus.GraphitePms.controller.ApprovalMain", {
        onInit: function () {
        }
    });
});
